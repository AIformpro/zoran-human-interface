from zui.core import *
print("OK")
