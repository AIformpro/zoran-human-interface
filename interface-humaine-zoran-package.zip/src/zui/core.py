class ZoranUI:
    def render(self, component):
        return f"Rendered {component}"
