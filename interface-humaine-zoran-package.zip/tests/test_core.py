from zui.core import ZoranUI
def test_render():
    ui = ZoranUI()
    assert "Rendered" in ui.render("dashboard")
